package io.grid.practice;

import com.badlogic.gdx.ApplicationListener;
import com.badlogic.gdx.Gdx;
import com.badlogic.gdx.Input;
import com.badlogic.gdx.audio.Sound;
import com.badlogic.gdx.graphics.Color;
import com.badlogic.gdx.graphics.GL20;
import com.badlogic.gdx.graphics.g2d.BitmapFont;
import com.badlogic.gdx.graphics.g2d.SpriteBatch;
import com.badlogic.gdx.graphics.glutils.ShapeRenderer;
import com.badlogic.gdx.math.MathUtils;

import java.io.BufferedReader;
import java.io.InputStream;
import java.io.InputStreamReader;
import java.io.OutputStream;
import java.net.HttpURLConnection;
import java.net.URL;
import java.nio.charset.StandardCharsets;
import java.util.ArrayList;
import java.util.Collections;
import java.util.Comparator;
import java.util.List;
import java.util.concurrent.ExecutorService;
import java.util.concurrent.Executors;

/**
 * A small 5x5 coin-collection game.
 * Move with the arrow keys or WASD. Collect coins before the 60-second timer expires.
 */
public class Main implements ApplicationListener {
    private static final int GRID_SIZE = 5;
    private static final float CELL_SIZE = 76f;
    private static final float GRID_X = 100f;
    private static final float GRID_Y = 50f;
    private static final float GAME_LENGTH_SECONDS = 60f;
    private static final float COIN_RELOCATE_SECONDS = 7f;

    // Configure these two values for your Firebase Realtime Database.
    // Example URL: https://your-project-default-rtdb.firebaseio.com
    private static final String FIREBASE_DATABASE_URL =
        System.getProperty("firebase.database.url", "");
    private static final String PLAYER_NAME =
        System.getProperty("player.name", "Player");

    private ShapeRenderer shapeRenderer;
    private SpriteBatch batch;
    private BitmapFont font;
    private Sound coinSound;

    // 0 = empty, 1 = player, 2 = coin
    private final int[][] grid = new int[GRID_SIZE][GRID_SIZE];
    private int playerRow, playerCol;
    private int score;
    private float timeLeft;
    private float coinRelocateTimer;
    private boolean gameOver;
    private boolean scoreSubmitted;
    private String statusMessage = "Collect the gold coins!";
    private final List<LeaderboardEntry> leaderboard = new ArrayList<LeaderboardEntry>();
    private final ExecutorService firebaseExecutor = Executors.newSingleThreadExecutor();
    private volatile boolean leaderboardLoaded;
    private volatile String firebaseMessage = "Firebase leaderboard not configured.";

    @Override
    public void create() {
        shapeRenderer = new ShapeRenderer();
        batch = new SpriteBatch();
        font = new BitmapFont();
        font.getData().setScale(1.15f);
        coinSound = Gdx.audio.newSound(Gdx.files.internal("coin_sound.mp3"));
        startNewGame();
        loadLeaderboard();
    }

    private void startNewGame() {
        for (int r = 0; r < GRID_SIZE; r++) {
            for (int c = 0; c < GRID_SIZE; c++) grid[r][c] = 0;
        }
        playerRow = MathUtils.random(0, GRID_SIZE - 1);
        playerCol = MathUtils.random(0, GRID_SIZE - 1);
        grid[playerRow][playerCol] = 1;
        placeCoin();
        score = 0;
        timeLeft = GAME_LENGTH_SECONDS;
        coinRelocateTimer = 0f;
        gameOver = false;
        scoreSubmitted = false;
        statusMessage = "Collect the gold coins!";
    }

    private void placeCoin() {
        int r, c;
        do {
            r = MathUtils.random(0, GRID_SIZE - 1);
            c = MathUtils.random(0, GRID_SIZE - 1);
        } while (grid[r][c] != 0);
        grid[r][c] = 2;
    }

    @Override
    public void render() {
        float delta = Math.min(Gdx.graphics.getDeltaTime(), 0.1f);

        if (!gameOver) {
            timeLeft -= delta;
            coinRelocateTimer += delta;
            if (timeLeft <= 0f) {
                timeLeft = 0f;
                finishGame();
            } else {
                handleMovement();
                // Random interaction: an uncollected coin may move to another empty cell.
                if (coinRelocateTimer >= COIN_RELOCATE_SECONDS) {
                    coinRelocateTimer = 0f;
                    if (MathUtils.randomBoolean(0.65f)) {
                        moveCoinRandomly();
                        statusMessage = "A coin moved to a new spot!";
                    }
                }
            }
        } else if (Gdx.input.isKeyJustPressed(Input.Keys.ENTER)
            || Gdx.input.isKeyJustPressed(Input.Keys.SPACE)
            || Gdx.input.isKeyJustPressed(Input.Keys.R)) {
            startNewGame();
        }

        Gdx.gl.glClearColor(0.15f, 0.15f, 0.2f, 1f);
        Gdx.gl.glClear(GL20.GL_COLOR_BUFFER_BIT);
        drawGrid();
        drawHud();
    }

    private void handleMovement() {
        int nextRow = playerRow;
        int nextCol = playerCol;

        if (Gdx.input.isKeyJustPressed(Input.Keys.UP) || Gdx.input.isKeyJustPressed(Input.Keys.W)) nextRow--;
        else if (Gdx.input.isKeyJustPressed(Input.Keys.DOWN) || Gdx.input.isKeyJustPressed(Input.Keys.S)) nextRow++;
        else if (Gdx.input.isKeyJustPressed(Input.Keys.LEFT) || Gdx.input.isKeyJustPressed(Input.Keys.A)) nextCol--;
        else if (Gdx.input.isKeyJustPressed(Input.Keys.RIGHT) || Gdx.input.isKeyJustPressed(Input.Keys.D)) nextCol++;

        if (nextRow < 0 || nextRow >= GRID_SIZE || nextCol < 0 || nextCol >= GRID_SIZE) return;
        if (nextRow == playerRow && nextCol == playerCol) return;

        if (grid[nextRow][nextCol] == 2) {
            score += 10;
            coinSound.play();
            statusMessage = "Coin collected! +10 points";
            grid[nextRow][nextCol] = 0;
            // Random interaction: each collected coin has a chance of a bonus or slowdown.
            int event = MathUtils.random(0, 4);
            if (event == 0) {
                score += 5;
                statusMessage = "Lucky bonus! +15 points";
            } else if (event == 1) {
                timeLeft = Math.max(0f, timeLeft - 3f);
                statusMessage = "Time surprise: -3 seconds!";
            }
            placeCoin();
        }

        grid[playerRow][playerCol] = 0;
        playerRow = nextRow;
        playerCol = nextCol;
        grid[playerRow][playerCol] = 1;
    }

    private void moveCoinRandomly() {
        int coinRow = -1, coinCol = -1;
        for (int r = 0; r < GRID_SIZE; r++) {
            for (int c = 0; c < GRID_SIZE; c++) {
                if (grid[r][c] == 2) { coinRow = r; coinCol = c; }
            }
        }
        if (coinRow < 0) return;
        grid[coinRow][coinCol] = 0;
        placeCoin();
    }

    private void drawGrid() {
        shapeRenderer.begin(ShapeRenderer.ShapeType.Filled);
        for (int r = 0; r < GRID_SIZE; r++) {
            for (int c = 0; c < GRID_SIZE; c++) {
                if (grid[r][c] == 1) shapeRenderer.setColor(Color.FIREBRICK);
                else if (grid[r][c] == 2) shapeRenderer.setColor(Color.GOLD);
                else shapeRenderer.setColor(Color.DARK_GRAY);
                shapeRenderer.rect(GRID_X + c * CELL_SIZE,
                    GRID_Y + (GRID_SIZE - 1 - r) * CELL_SIZE, CELL_SIZE - 4, CELL_SIZE - 4);
            }
        }
        shapeRenderer.end();
    }

    private void drawHud() {
        batch.begin();
        font.setColor(Color.WHITE);
        font.draw(batch, "Score: " + score, 100, 490);
        font.draw(batch, "Time: " + (int)Math.ceil(timeLeft) + "s", 260, 490);
        font.draw(batch, "Move: Arrow keys or WASD", 100, 465);
        font.draw(batch, statusMessage, 100, 30);

        if (gameOver) {
            font.setColor(Color.GOLD);
            font.getData().setScale(2f);
            font.draw(batch, "GAME OVER", 220, 330);
            font.getData().setScale(1.15f);
            font.setColor(Color.WHITE);
            font.draw(batch, "Final score: " + score, 220, 295);
            font.draw(batch, "Press ENTER, SPACE, or R to restart", 120, 255);
            font.draw(batch, "TOP 3 LEADERBOARD", 220, 210);
            if (!leaderboardLoaded && !FIREBASE_DATABASE_URL.isEmpty()) {
                font.draw(batch, "Loading scores...", 220, 180);
            } else if (leaderboard.isEmpty()) {
                font.draw(batch, firebaseMessage, 120, 180);
            } else {
                for (int i = 0; i < Math.min(3, leaderboard.size()); i++) {
                    LeaderboardEntry entry = leaderboard.get(i);
                    font.draw(batch, (i + 1) + ". " + entry.name + " - " + entry.score, 220, 180 - i * 25);
                }
            }
        }
        batch.end();
    }

    private void finishGame() {
        if (gameOver) return;
        gameOver = true;
        statusMessage = "Game finished!";
        // Reuse the supplied sound asset for the end-of-game cue.
        coinSound.play(0.7f);
        submitScore();
    }

    private void loadLeaderboard() {
        if (FIREBASE_DATABASE_URL == null || FIREBASE_DATABASE_URL.trim().isEmpty()) return;
        firebaseExecutor.submit(new Runnable() {
            @Override public void run() {
                try {
                    String json = httpGet(databaseEndpoint());
                    List<LeaderboardEntry> entries = parseEntries(json);
                    Collections.sort(entries, new Comparator<LeaderboardEntry>() {
                        @Override public int compare(LeaderboardEntry a, LeaderboardEntry b) {
                            return Integer.compare(b.score, a.score);
                        }
                    });
                    synchronized (leaderboard) {
                        leaderboard.clear();
                        leaderboard.addAll(entries.subList(0, Math.min(3, entries.size())));
                    }
                    firebaseMessage = "Leaderboard loaded.";
                } catch (Exception e) {
                    firebaseMessage = "Firebase unavailable. Check setup.";
                } finally {
                    leaderboardLoaded = true;
                }
            }
        });
    }

    private void submitScore() {
        if (scoreSubmitted) return;
        scoreSubmitted = true;
        if (FIREBASE_DATABASE_URL == null || FIREBASE_DATABASE_URL.trim().isEmpty()) {
            firebaseMessage = "Set Firebase database URL to enable scores.";
            return;
        }
        final int submittedScore = score;
        firebaseExecutor.submit(new Runnable() {
            @Override public void run() {
                try {
                    String safeName = PLAYER_NAME.replace("\\", "\\\\").replace("\"", "\\\"");
                    String body = "{\"name\":\"" + safeName + "\",\"score\":" + score + "}";
                    httpPut(databaseEndpoint() + "/" + System.currentTimeMillis() + ".json", body);
                    leaderboardLoaded = false;
                    loadLeaderboard();
                } catch (Exception e) {
                    firebaseMessage = "Score could not be uploaded.";
                }
            }
        });
    }

    private String databaseEndpoint() {
        String url = FIREBASE_DATABASE_URL.trim();
        while (url.endsWith("/")) url = url.substring(0, url.length() - 1);
        return url + "/leaderboard";
    }

    private String httpGet(String address) throws Exception {
        HttpURLConnection connection = (HttpURLConnection)new URL(address + ".json").openConnection();
        connection.setRequestMethod("GET");
        connection.setConnectTimeout(5000);
        connection.setReadTimeout(5000);
        try {
            return readResponse(connection);
        } finally { connection.disconnect(); }
    }

    private void httpPut(String address, String body) throws Exception {
        HttpURLConnection connection = (HttpURLConnection)new URL(address + ".json").openConnection();
        connection.setRequestMethod("PUT");
        connection.setDoOutput(true);
        connection.setConnectTimeout(5000);
        connection.setReadTimeout(5000);
        connection.setRequestProperty("Content-Type", "application/json; charset=UTF-8");
        try {
            OutputStream out = connection.getOutputStream();
            out.write(body.getBytes(StandardCharsets.UTF_8));
            out.close();
            readResponse(connection);
        } finally { connection.disconnect(); }
    }

    private String readResponse(HttpURLConnection connection) throws Exception {
        int code = connection.getResponseCode();
        InputStream stream = code >= 200 && code < 300 ? connection.getInputStream() : connection.getErrorStream();
        if (stream == null) throw new IllegalStateException("Firebase HTTP " + code);
        BufferedReader reader = new BufferedReader(new InputStreamReader(stream, StandardCharsets.UTF_8));
        StringBuilder result = new StringBuilder();
        String line;
        while ((line = reader.readLine()) != null) result.append(line);
        reader.close();
        if (code < 200 || code >= 300) throw new IllegalStateException("Firebase HTTP " + code + ": " + result);
        return result.toString();
    }

    // Parses the small JSON object returned by Realtime Database without an extra library.
    private List<LeaderboardEntry> parseEntries(String json) {
        List<LeaderboardEntry> result = new ArrayList<LeaderboardEntry>();
        if (json == null || json.equals("null") || json.length() < 2) return result;
        java.util.regex.Matcher matcher = java.util.regex.Pattern.compile(
            "\\\"name\\\"\\s*:\\s*\\\"((?:\\\\.|[^\\\"])*)\\\"\\s*,\\s*\\\"score\\\"\\s*:\\s*(\\d+)"
        ).matcher(json);
        while (matcher.find()) {
            String name = matcher.group(1).replace("\\\"", "\"").replace("\\\\", "\\");
            result.add(new LeaderboardEntry(name, Integer.parseInt(matcher.group(2))));
        }
        return result;
    }

    private static class LeaderboardEntry {
        final String name;
        final int score;
        LeaderboardEntry(String name, int score) { this.name = name; this.score = score; }
    }

    @Override public void resize(int width, int height) {}
    @Override public void pause() {}
    @Override public void resume() {}

    @Override
    public void dispose() {
        if (shapeRenderer != null) shapeRenderer.dispose();
        if (batch != null) batch.dispose();
        if (font != null) font.dispose();
        if (coinSound != null) coinSound.dispose();
        firebaseExecutor.shutdownNow();
    }
}
