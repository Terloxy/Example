# Grid Coin Collector

A small desktop grid game built with **libGDX**.

## How to play
- Move the red player square with the arrow keys or **WASD**.
- Collect the gold coin to earn **10 points**.
- Some collections trigger a random bonus or a small time penalty.
- Coins may randomly relocate while you play.
- You have **60 seconds** to collect as many coins as possible.
- When time runs out, the game-over screen shows your final score and the top-three leaderboard.
- Press **Enter**, **Space**, or **R** on the game-over screen to restart.

## Sound
The game uses `assets/coin_sound.mp3` when a coin is collected and as the game-over sound cue.

## Run
From the project folder on Windows:

```bat
gradlew.bat lwjgl3:run
```

## Firebase Realtime Database leaderboard
This desktop version communicates with Firebase Realtime Database using its REST endpoint.

1. Create a Firebase project at https://console.firebase.google.com/.
2. In **Build → Realtime Database**, create a database.
3. Copy the database URL shown in the Firebase console (for example, `https://YOUR-PROJECT-default-rtdb.firebaseio.com`).
4. Configure the URL when launching the game:

```bat
gradlew.bat lwjgl3:run -Pfirebase.database.url=https://YOUR-PROJECT-default-rtdb.firebaseio.com -Pplayer.name=YourName
```

The game writes score records under `/leaderboard` and displays the three highest scores.

### Important security note
Do **not** leave a public database writable in a real/public game. A desktop application cannot safely contain administrator credentials. For a classroom demonstration, configure appropriate temporary test rules only if your instructor permits them, then lock the database afterward. For a public release, put score submission behind Firebase Authentication plus trusted server-side validation (such as Cloud Functions), and use rules that prevent users from changing other players' scores. Never put a service-account JSON file in this project.

## Notes
The leaderboard uses Realtime Database (not Cloud Firestore). No Firebase SDK or service-account key is required in the desktop client; it uses the database REST endpoint.
